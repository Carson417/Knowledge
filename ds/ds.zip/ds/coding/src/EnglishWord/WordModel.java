package EnglishWord;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class WordModel {

    /**
     * 英译
     */
    private String wordEn;
    /**
     * 熟悉的中译
     */
    private String wordFamiliarCn;
    /**
     * 不熟悉的中译
     */
    private String wordUnFamiliarCn;
    /**
     * 忘记次数
     */
    private int forgetCount;

}
