package EnglishWord;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * 英语单词备忘录
 */
public class memo {


    private static final String FILE_PATH = "src/EnglishWord/Memo"; // 文件路径
    private static final List<WordModel> wordList = new ArrayList<>();

    public static void main(String[] args) {
        // 1. 启动时加载文件数据
        loadWordsFromFile();

        // 2. 持续输入循环
        try (Scanner sc = new Scanner(System.in)) {
            while (true) {
                System.out.println("\n请输入单词信息（格式：英文 熟悉中译 不熟悉中译），或输入 'exit' 退出：");
                String input = sc.nextLine().trim();

                if (input.equalsIgnoreCase("exit")) {
                    break; // 退出循环
                }

                String[] parts = input.split(" ");
                if (parts.length < 3) {
                    System.err.println("输入格式错误！请按格式输入。");
                    continue;
                }

                // 3. 更新单词列表
                updateWordList(parts[0], parts[1], parts[2]);

                // 4. 实时写入文件（可选）
                saveWordsToFile();
                System.out.println("单词已保存！");
            }
        }

        // 5. 程序退出前保存最终数据（确保数据持久化）
        saveWordsToFile();
        System.out.println("程序已退出，数据已保存至文件。");
    }

    // 从文件加载单词1
    private static void loadWordsFromFile() {
        try (Scanner fileScanner = new Scanner(new File(FILE_PATH))) {
            while (fileScanner.hasNextLine()) {
                String line = fileScanner.nextLine();
                String[] data = line.split("\t\t\t");
                if (data.length >= 3) {
                    wordList.add(new WordModel(data[0], data[1], data[2], Integer.parseInt(data[3])));
                }
            }
        } catch (FileNotFoundException e) {
            System.err.println("文件未找到，将创建新文件。");
        }
    }

    // 更新单词列表（新增或修改）
    private static void updateWordList(String en, String familiarCn, String unfamiliarCn) {
        for (WordModel word : wordList) {
            if (word.getWordEn().equals(en)) {
                word.setWordFamiliarCn(familiarCn);
                word.setWordUnFamiliarCn(unfamiliarCn);
                word.setForgetCount(word.getForgetCount() + 1);
                return;
            }
        }
        wordList.add(new WordModel(en, familiarCn, unfamiliarCn, 1));
    }

    // 保存单词列表到文件
    private static void saveWordsToFile() {
        try (PrintWriter pw = new PrintWriter(new FileWriter(FILE_PATH))) {
            for (WordModel word : wordList) {
                pw.println(word.getWordEn() + "\t\t\t" +
                        word.getWordFamiliarCn() + "\t\t\t" +
                        word.getWordUnFamiliarCn() + "\t\t\t" +
                        word.getForgetCount());
            }
        } catch (IOException e) {
            throw new RuntimeException("保存文件失败", e);
        }
    }


}
