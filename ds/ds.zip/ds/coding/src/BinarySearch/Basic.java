package BinarySearch;

public class Basic {

    public static void main(String[] args) {
        int[] arr = {1, 2, 3, 4, 5, 6};
        int target = 7;
        int result = binarySearch1(arr, target);
        System.out.println(result);
    }


    public static int binarySearch1(int[] arr, int target) {
        int left = 0;
        int right = arr.length - 1;

        while (left <= right) {
            int mid = (left + right) >> 1;
            if (target < arr[mid]) {
                right = mid - 1;
            } else if (target > arr[mid]) {
                left = mid + 1;
            } else {
                return mid;
            }
        }
        return -1;
    }


    public static int binarySearch2(int[] arr, int target) {
        int left = 0;
        int right = arr.length;

        while (left < right) {
            int mid = (left + right) >> 1;
            if (target < arr[mid]) {
                right = mid;
            } else if (target > arr[mid]) {
                left = mid + 1;
            } else {
                return mid;
            }
        }
        return -1;
    }


    public static int binarySearch3(int[] arr, int target) {
        int left = 0;
        int right = arr.length;

        while (right - left > 1) {
            int mid = (left + right) >>> 1;
            if (target < arr[mid]) {
                right = mid;
            } else {
                left = mid;         //这里是>= 的情况，所以不能+1
            }
        }
        if (target == arr[left]) {
            return left;
        }
        return -1;
    }
}
