package leetcode;

/**
 * 反转链表
 */

public class Q206_reverseLinkedList {

    /**
     * 方一：创建一个新链表，使用头插法，旧链表中每遍历一个，新链表就新增一个
     */
    public ListNode reverseList_m1(ListNode head) {
        ListNode newHead = null;
        ListNode p = head;
        while (p != null) {
            newHead = new ListNode(p.val, newHead);
            p = p.next;
        }
        return newHead;
    }


    /**
     * 方二：和方一类似，区别在 旧链表遍历到的节点，直接移除，添加到新链表中
     */
    public ListNode reverseList_m2(ListNode head) {
        List list1 = new List(head);
        List list2 = new List(null);

        while (true) {
            ListNode first = list1.removeFirst();
            if (first == null) {
                break;
            }
            list2.addFirst(first);
        }
        return list2.head;
    }


    /**
     * 方三：递归
     */
    public ListNode reverseList_m3(ListNode p) {
        if (p == null || p.next == null) {
            return p;   // 最后节点
        }
        ListNode last = reverseList_m3(p.next); // 最先返回的这个last就是最后一个节点
        // 此时的p是倒数第二个节点，p.next是最后一个节点
        p.next.next = p;
        // 此步骤后的结果是，1 -> 2 <- 3, 2 -> null
        p.next = null;
        // 实际上这个last也是最终的反转后的head了
        return last;
    }


    /**
     * 方四：双链表
     * <p>
     * 开始 o1,n1都指向head
     * 每次都是把 o2 从链表中断开，头插到 n中，o1则是直接连上o3
     */
    public ListNode reverseList_m4(ListNode o1) {
        // 1.空链表  2.一个元素
        if (o1 == null || o1.next == null) {
            return o1;
        }
        ListNode n1 = o1;
        ListNode o2 = o1.next;
        while (o2 != null) {
            o1.next = o2.next;
            o2.next = n1;
            n1 = o2;
            o2 = o1.next;
        }
        return n1;
    }


    /**
     * 方五：双指针，和方二同，但是不用定义list
     * 不断的把旧链表的头，搬到新链表头插
     */
    public ListNode reverseList_m5(ListNode o1) {
        if (o1 == null || o1.next == null) {
            return o1;
        }
        ListNode n1 = null;
        while (o1 != null) {
            ListNode o2 = o1.next;
            o1.next = n1;
            n1 = o1;
            o1 = o2;
        }
        return n1;
    }


    public static class List {
        ListNode head;

        public List(ListNode head) {
            this.head = head;
        }

        public void addFirst(ListNode first) {
            first.next = head;
            head = first;
        }

        public ListNode removeFirst() {
            ListNode first = head;
            if (first != null) {
                head = first.next;
            }
            return first;
        }
    }
}
