package leetcode;

public class Q203_deleteNodeByValue {

    /**
     * 方一：双指针
     */
    public ListNode removeElements1(ListNode head, int val) {
        ListNode s = new ListNode(-1, head);
        ListNode prev = s;
        ListNode curr = s.next;

        while (curr != null) {
            if (curr.val == val) {
                prev.next = curr.next;

            } else {
                prev = prev.next;
            }
            curr = curr.next;
        }
        return s.next;
    }


    /**
     * 方二：递归
     */

}
