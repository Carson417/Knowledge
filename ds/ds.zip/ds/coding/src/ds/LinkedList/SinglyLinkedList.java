package ds.LinkedList;

import java.util.Iterator;
import java.util.function.Consumer;

public class SinglyLinkedList implements Iterable<Integer> {

    private Node head; // 头部节点

    @Override
    public Iterator<Integer> iterator() {
        return new Iterator<Integer>() {
            Node p = head;

            @Override
            public boolean hasNext() {
                return p != null;
            }

            @Override
            public Integer next() {
                int res = p.value;
                p = p.next;
                return res;
            }
        };
    }

    private static class Node { // 节点类
        int value;
        Node next;

        public Node(int value, Node next) {
            this.value = value;
            this.next = next;
        }
    }


    public void addFirst(int value) {
        // 链表为空
        head = new Node(value, null);
        // 链表非空
        head = new Node(value, head);
    }


    public void loop_while(Consumer<Integer> consumer) {
        for (Node p = head; p != null; p = p.next) {
            consumer.accept(p.value);
        }
    }


    private Node findLast() {
        if (head == null) {
            return null;
        }
        Node p;
        for (p = head; p.next != null; p = p.next) {
        }
        return p;
    }

    public void addLast(int value) {
        Node last = findLast();
        if (last == null) {
            addFirst(value);
            return;
        }
        last.next = new Node(value, null);
    }


    private Node findNodeByIndex(int index) {
        int i = 0;
        for (Node p = head; p != null; p = p.next, i++) {
            if (index == i) {
                return p;
            }
        }
        return null;
    }

    public int nodeValue(int index) {
        Node node = findNodeByIndex(index);
        if (node == null) {
            throw new IllegalArgumentException(String.format("index[%d]不合法%n", index));
        }
        return node.value;
    }

    public void insertByIndex(int value, int index) {
        if (index == 0) {
            addFirst(value);
        }
        Node prev = findNodeByIndex(index - 1);
        if (prev == null) {
            throw new IllegalArgumentException(String.format("index[%d]不合法%n", index));
        }
        prev.next = new Node(value, prev.next);
    }


    public void removeFirst() {
        if (head == null) {
            throw new IllegalArgumentException(String.format("index[%d]不合法%n", 0));
        }
        head = head.next;
    }

    public void removeByIndex(int index) {
        if (index == 0) {
            removeFirst();
            return;
        }
        if (findNodeByIndex(index - 1) == null || findNodeByIndex(index) == null) {
            throw new IllegalArgumentException(String.format("index[%d]不合法%n", index));
        }
        Node prev = findNodeByIndex(index - 1);
        Node curr = findNodeByIndex(index);
        prev.next = curr.next;
    }

    // 递归遍历
    public void recursionLoop(Consumer<Integer> before, Consumer<Integer> after) {
        recursion(head, before, after);
    }

    private void recursion(Node p, Consumer<Integer> before, Consumer<Integer> after) {
        if (p == null) {
            return;
        }
        before.accept(p.value);
        recursion(p.next, before, after);
        after.accept(p.value);
    }
}
