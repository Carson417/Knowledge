package ds.LinkedList;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.Iterator;

/**
 * 带哨兵的双向链表
 */
public class DoublyLinkedListSentinel implements Iterable {

    @Override
    public Iterator<Integer> iterator() {
        return new Iterator<>() {
            Node p = head.next;

            @Override
            public boolean hasNext() {
                return p != tail;
            }

            @Override
            public Integer next() {
                int value = p.value;
                p = p.next;
                return value;
            }
        };
    }

    @Data
    @AllArgsConstructor
    private static class Node { // 节点类
        Node prev;
        int value;
        Node next;
    }

    // 头哨兵，尾哨兵
    private Node head;
    private Node tail;

    public DoublyLinkedListSentinel() {
        head = new Node(null, Integer.MIN_VALUE, null);
        tail = new Node(null, Integer.MIN_VALUE, null);
        head.next = tail;
        tail.prev = head;
    }

    private Node findNode(int index) {
        int i = -1;
        for (Node p = head; p != tail; p = p.next, i++) {
            if (i == index) {
                return p;
            }
        }
        return null;
    }

    private void insert(int index, int value) {
        Node prev = findNode(index - 1);
        if (prev == null) {
            throw new IllegalArgumentException(String.format("index[%d]不合法%n", index));
        }
        Node curr = findNode(index);
        Node p = new Node(prev, value, curr);
        prev.next = p;
        curr.prev = p;
    }

    public void addFirst(int value) {
        insert(0, value);
    }

    public void addLast(int value) {
        Node p = new Node(tail.prev, value, tail);
        tail.prev.next = p;
        tail.prev = p;
    }

    public void remove(int index) {
        Node prev = findNode(index - 1);
        Node removed = findNode(index);
        if (prev == null || removed == tail) {
            throw new IllegalArgumentException(String.format("index[%d]不合法%n", index));
        }
        prev.next = removed.next;
        removed.next.prev = prev;
    }

    public void removeFirst() {
        remove(0);
    }

    public void removedLast() {
        Node last = tail.prev;
        if (last == head) {
            throw new IllegalArgumentException("index不合法%n");
        }
        last.prev.next = tail;
        tail.prev = last.prev;
    }


}
