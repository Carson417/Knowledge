package ds.LinkedList;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.Iterator;

/**
 * 双向环形链表
 */
public class DoublyCircleLinkedListSentinel implements Iterable<Integer> {

    @Override
    public Iterator<Integer> iterator() {
        return new Iterator<>() {
            Node p = sentinel.next;

            @Override
            public boolean hasNext() {
                return p != sentinel;
            }

            @Override
            public Integer next() {
                int value = p.value;
                p = p.next;
                return value;
            }
        };
    }

    @Data
    @AllArgsConstructor
    private static class Node {
        Node prev;
        int value;
        Node next;
    }

    private Node sentinel = new Node(null, Integer.MIN_VALUE, null);

    public DoublyCircleLinkedListSentinel() {
        sentinel.prev = sentinel;
        sentinel.next = sentinel;
    }

    public void addFirst(int value) {
        Node add = new Node(sentinel, value, sentinel.next);
        sentinel.next.prev = add;
        sentinel.next = add;
    }

    public void addLast(int value) {
        Node add = new Node(sentinel.prev, value, sentinel);
        sentinel.prev.next = add;
        sentinel.prev = add;
    }

    public void removeFirst() {
        Node p = sentinel.next;
        if (p == sentinel) {
            throw new IllegalArgumentException("index不合法%n");
        }
        p.next.prev = sentinel;
        sentinel.next = p.next;
    }

    public void removeLast() {
        Node removed = sentinel.prev;
        if (removed == sentinel) {
            throw new IllegalArgumentException("index不合法%n");
        }
        removed.prev.next = sentinel;
        sentinel.prev = removed.prev;
    }

    private Node findByValue(int value) {
        for (Node p = sentinel.next; p != sentinel; p = p.next) {
            if (p.value == value) {
                return p;
            }
        }
        return null;
    }

    public void removeByValue(int value) {
        Node removed = findByValue(value);
        if (removed == null) {
            return;
        }
        removed.next.prev = removed.prev;
        removed.prev.next = removed.next;
    }
}
