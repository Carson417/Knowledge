package ds.LinkedList;

public class SinglyLinkedListSentinel {

    private static class Node { // 节点类
        int value;
        Node next;

        public Node(int value, Node next) {
            this.value = value;
            this.next = next;
        }
    }

    private Node head = new Node(-1, null);


    private Node findLast() {
        Node p;
        for (p = head; p.next != null; p = p.next) {
        }
        return p;
    }

    public void addLast(int value) {
        findLast().next = new Node(value, null);
    }

    /**
     * 遍历的起点也要变成head.next
     */


    private Node findNodeByIndex(int index) {
        // 哨兵的索引算-1
        int i = -1;
        for (Node p = head; p != null; p = p.next, i++) {
            if (index == i) {
                return p;
            }
        }
        return null;
    }

    public int nodeValue(int index) {
        Node node = findNodeByIndex(index);
        if (node == null) {
            throw new IllegalArgumentException(String.format("index[%d]不合法%n", index));
        }
        return node.value;
    }

    public void insertByIndex(int value, int index) {
        Node prev = findNodeByIndex(index - 1);
        if (prev == null) {
            throw new IllegalArgumentException(String.format("index[%d]不合法%n", index));
        }
        prev.next = new Node(value, prev.next);
    }


    public void addFirst(int value) {
        insertByIndex(value, 0);
    }


    public void removeFirst() {
        removeByIndex(0);
    }

    public void removeByIndex(int index) {
        if (findNodeByIndex(index - 1) == null || findNodeByIndex(index) == null) {
            throw new IllegalArgumentException(String.format("index[%d]不合法%n", index));
        }
        Node prev = findNodeByIndex(index - 1);
        Node curr = findNodeByIndex(index);
        prev.next = curr.next;
    }
}
