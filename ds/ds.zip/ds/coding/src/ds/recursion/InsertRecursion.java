package ds.recursion;


import java.util.Arrays;

/**
 * 递归实现插入排序
 */
public class InsertRecursion {

    public static void main(String[] args) {
        int[] arr = {5, 2, 7, 3, 8, 4, 9, 1};
        insertRecursion(arr, 1);
        System.out.println(Arrays.toString(arr));
    }

    /**
     * low是未有序的左边界
     */
    public static void insertRecursion(int[] arr, int low) {
        if (low == arr.length) {
            return;
        }
        int temp = arr[low];
        int i = low - 1;
        while (i >= 0 && arr[i] > temp) {
            arr[i + 1] = arr[i];
            i--;
        }
        arr[i + 1] = temp;

        insertRecursion(arr, low + 1);
    }


    /**
     * low是未有序的左边界
     */
    public static void insertRecursion1(int[] arr, int low) {
        if (low == arr.length) {
            return;
        }
        int temp = arr[low];
        int i = low - 1;
        while (i >= 0 && arr[i] > temp) {
            arr[i + 1] = arr[i];
            i--;
        }
        // 这个未排序的元素本来就比已排序的最大的还大，那就不用再插了
        if (i + 1 != low) {
            arr[i + 1] = temp;
        }


        insertRecursion(arr, low + 1);
    }

}
