package ds.recursion;

import java.util.Arrays;

public class FibonacciRecursion {

    public static void main(String[] args) {

        fibonacci(5);
        int rabbit = rabbit(6);
        System.out.println(rabbit);
    }


    public static int fibonacci(int n) {
        if (n == 0) {
            return 0;
        }
        if (n == 1) {
            return 1;
        }
        return fibonacci(n - 1) + fibonacci(n - 2);
    }


    /**
     * 优化---记忆法
     */
    public static int fibonacciMemo(int n) {
        int[] cache = new int[n + 1];
        Arrays.fill(cache, -1);
        cache[0] = 0;
        cache[1] = 1;
        return f(n, cache);
    }

    private static int f(int n, int[] cache) {
        if (cache[n] != -1) {
            return cache[n];
        }
        int x = f(n - 1, cache);
        int y = f(n - 2, cache);
        cache[n] = x + y;
        return cache[n];
    }

    /**
     * 变体问题1 --- 兔子问题
     */
    public static int rabbit(int n) {
        if (n == 0) {
            return 0;
        }
        if (n == 1) {
            return 1;
        }
        return rabbit(n - 1) + rabbit(n - 2);
    }

    /**
     * 青蛙跳台阶
     */
    public int jump(int n) {
        if (n == 0) {
            return 0;
        }
        if (n == 1 || n == 2) {
            return 1;
        }
        return jump(n - 1) + jump(n - 2);
    }
}