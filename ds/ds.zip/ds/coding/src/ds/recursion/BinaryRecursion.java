package ds.recursion;


/**
 * 二分查找的递归写法
 */
public class BinaryRecursion {

    public static void main(String[] args) {
        int[] arr = {1, 2, 3, 4, 5};
        int i = binaryRecursion(arr, 0, arr.length - 1, -4);
        System.out.println(i);
    }

    public static int binaryRecursion(int[] arr, int left, int right, int target) {
        if (left > right) {
            return -1;
        }
        int mid = (left + right) >>> 1;
        if (arr[mid] > target) {
            binaryRecursion(arr, left, mid - 1, target);
        } else if (arr[mid] < target) {
            binaryRecursion(arr, mid + 1, right, target);
        } else {
            return mid;
        }
        return -1;
    }


}
