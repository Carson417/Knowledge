package ds.recursion;

import java.util.LinkedList;

public class Hanoi {

    private static final LinkedList<Integer> a = new LinkedList<>();

    static void init(int n) {
        for (int i = n; i >= 1; i--) {
            a.addLast(i);
        }
    }

    /**
     * a是原，b是中间，c是终
     */
    public static void hanoi(int n,
                             LinkedList<Integer> a,
                             LinkedList<Integer> b,
                             LinkedList<Integer> c) {
        if (n == 0) {
            return;
        }
        hanoi(n - 1, a, c, b);
        c.addLast(a.removeLast());
        hanoi(n - 1, b, a, c);
    }

    public static void main(String[] args) {
        init(3);
    }
}
