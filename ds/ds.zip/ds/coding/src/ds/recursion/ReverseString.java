package ds.recursion;

public class ReverseString {

    public static void main(String[] args) {
        reverse("abcd",0);
    }


    public static void reverse(String str, int n) {
        if (n == str.length()) {
            return;
        }
        reverse(str, n + 1);
        System.out.println(str.charAt(n));

    }
}
