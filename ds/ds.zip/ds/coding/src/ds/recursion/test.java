package ds.recursion;

import lombok.AllArgsConstructor;
import lombok.Data;

public class test {

    @Data
    @AllArgsConstructor
    private static class A {
        int x;
        Integer y;

//        public A(Integer x, Integer y) {
//            this.x = x;
//            this.y = y;
//            System.out.println("构造器启用了");
//        }
    }

    public static void main(String[] args) {
        A a = new A(Integer.MIN_VALUE, null);
        System.out.println(a);
    }
}
