package ds.recursion;

/**
 * 递归出现的爆栈问题
 */
public class StackOverFlowRecursion {

    public static void main(String[] args) {

    }


    /**
     * 最基本的求和
     */
    public static long sum(int n) {
        if (n == 1) {
            return 1;
        }
        return n + sum(n - 1);
    }
}
