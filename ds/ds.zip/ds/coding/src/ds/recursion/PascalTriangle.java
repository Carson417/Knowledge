package ds.recursion;

/**
 * 杨辉三角
 */
public class PascalTriangle {

    public int element(int i, int j) {

        if (j == 0 || i == j) {
            return 1;
        }
        return element(i - 1, j - 1) + element(i - 1, j);
    }

    /**
     # 二维数组优化法
     */
    public int element_memo(int[][] triangle, int i, int j) {
        if (j == 0 || i == j) {
            triangle[i][j] = 1;
            return 1;
        }
        if (triangle[i][j] > 0) {
            return triangle[i][j];
        }
        triangle[i][j] = element_memo(triangle, i - 1, j - 1) + element_memo(triangle, i - 1, j);
        return triangle[i][j];
    }


    /**
     * 一维数组优化法 --- 都不用递归了 --- 动态规划
     * 0 0 0 0 0 0 初始
     * 1 0 0 0 0 0 i=0
     * 1 1 0 0 0 0 i=1
     * 1 2 1 0 0 0 i=2
     * 1 3 3 1 0 0 i=3
     * 1 4 6 4 1 0 i=4
     */
    public static void createRow(int[] row, int i) {
        if (i == 0) {
            row[0] = 1;
            return;
        }
        for (int j = i; j > 0; j--) {
            row[j] = row[j] + row[j - 1];
        }
    }
}
