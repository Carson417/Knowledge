package ds.recursion;

import java.util.Arrays;

public class BubbleRecursion {


    public static void main(String[] args) {
        int[] arr = {5, 2, 7, 3, 8, 4, 9, 1};
//        bubble(arr);
//        bubbleRecursion(arr, arr.length - 1);
//        bubbleRecursion1(arr, arr.length - 1);
        bubbleRecursion2(arr, arr.length - 1);
        System.out.println(Arrays.toString(arr));
    }


    public static void bubbleRecursion(int[] arr, int right) {
        if (right == 0) {
            return;
        }
        for (int i = 0; i < right; i++) {
            if (arr[i] > arr[i + 1]) {
                int temp = arr[i];
                arr[i] = arr[i + 1];
                arr[i + 1] = temp;
            }
        }
        bubbleRecursion(arr, right - 1);
    }


    /**
     * 优化版，如果后续都有序就不用继续递归了  --- 自己想的
     */
    public static void bubbleRecursion1(int[] arr, int right) {
        if (right == 0) {
            return;
        }
        boolean ifChange = false;
        for (int i = 0; i < right; i++) {
            if (arr[i] > arr[i + 1]) {
                int temp = arr[i];
                arr[i] = arr[i + 1];
                arr[i + 1] = temp;
                ifChange = true;
            }
        }
        if (!ifChange) {
            return;
        }
        bubbleRecursion1(arr, right - 1);
    }

    /**
     * 优化版，如果后续都有序就不用继续递归了
     * <p>
     * x代表未排序的右边界
     */
    public static void bubbleRecursion2(int[] arr, int right) {
        if (right == 0) {
            return;
        }
        int x = 0;
        for (int i = 0; i < right; i++) {
            if (arr[i] > arr[i + 1]) {
                int temp = arr[i];
                arr[i] = arr[i + 1];
                arr[i + 1] = temp;
                x = i;
            }
        }
        bubbleRecursion2(arr, x);
    }


    public static void bubble(int[] arr) {
        for (int i = 0; i < arr.length - 1; i++) {
            for (int j = 0; j < arr.length - 1 - i; j++) {
                if (arr[j] > arr[j + 1]) {
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }
    }
}
